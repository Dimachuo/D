[Для использовавния GPT]
1) $ cd GPT
2) $ cd script
3) $ bash install Auto-install.sh
# Заходим через Браузер на сылку адресации через открытый Ситемный API регестрируемся генерируем ключ OPENAI-API копируем вставляем  Для примера : key = "Вставьте_Скопированный_Ключ_API_" Теперь CTRL + O / CTRL + X или CTRL + X + Y
Авто *
 $ cd GPT/script && bash install Auto-install.sh
 
[Копирование Файла]
 
 $ cd CopyStorageGPTX
 # Для переноса в Termux 
 $ bash BackupTermuxGPTX.sh
 # Для переноса в storage
 $ bash BackupStorageGPTX.sh
 
 Также добавил адресацию направления на сам *Chat GPT* открытие через Системный АРІ
 
 $ cd CHATGPT-OpenAI-URL
 $ bash CHATGPT.sh
 
 Авто *
 
 $ cd CHATGPT-OpenAI-URL && bash CHATGPT.sh
 
 
 


