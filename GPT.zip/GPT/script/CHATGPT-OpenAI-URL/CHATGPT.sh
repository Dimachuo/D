apt install termux-api ; clear && chmod 777 CHATGPT.sh && termux-open-url https://chat.openai.com/ 
